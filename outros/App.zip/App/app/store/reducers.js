/**
 * Created by dbuarque on 6/20/16.
 */
import { combineReducers } from 'redux';
import home from './../modules/home/reducers/index';

export default combineReducers({
  home
});
